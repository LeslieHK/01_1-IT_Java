activiti-explorer-rest integrated
=================

( version : 5.15.1 )

mvn jetty:run

[![Build Status](https://travis-ci.org/izerui/activiti-explorer.png?branch=master)](https://travis-ci.org/izerui/activiti-explorer)
