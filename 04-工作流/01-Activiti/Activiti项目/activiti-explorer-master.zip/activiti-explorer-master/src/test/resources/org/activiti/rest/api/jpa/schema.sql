drop table if exists message;
create table message (
  id int,
  text varchar(100)
);