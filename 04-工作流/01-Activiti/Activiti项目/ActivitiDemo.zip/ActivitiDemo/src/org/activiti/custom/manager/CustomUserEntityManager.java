package org.activiti.custom.manager;

import java.util.List;

import javax.annotation.Resource;

import org.activiti.engine.identity.Group;
import org.activiti.engine.identity.User;
import org.activiti.engine.impl.Page;
import org.activiti.engine.impl.UserQueryImpl;
import org.activiti.engine.impl.persistence.entity.IdentityInfoEntity;
import org.activiti.engine.impl.persistence.entity.UserEntity;
import org.activiti.engine.impl.persistence.entity.UserEntityManager;
import org.activiti.extsys.service.AccountManagerService;
import org.activiti.util.ActivitiUtils;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;  
  
/**
 * 自定义的Activiti用户管理器 
 * @author 陈少钦
 * @date 2017/06/05
 */
@Service  
public class CustomUserEntityManager extends UserEntityManager {  
    //private static final Log logger = LogFactory.getLog(CustomUserEntityManager.class);  
  
    @Resource  
    private AccountManagerService accountManagerService;
  
    @Override  
    public UserEntity findUserById(final String userCode) {  
        if (userCode == null)  
            return null;  
  
        try {  
            UserEntity userEntity = new UserEntity();  
            org.activiti.extsys.entity.User bUser = accountManagerService.getUserByUserId(userCode);
            userEntity.setEmail(bUser.getEmail());
            userEntity.setFirstName(bUser.getFirstName());
            userEntity.setId(bUser.getId());
            userEntity.setLastName(bUser.getLastName());
            userEntity.setPicture(null);
            userEntity.setRevision(1);
            return userEntity;  
        } catch (EmptyResultDataAccessException e) {  
            return null;  
        }  
    }  
  
    @Override  
    public List<Group> findGroupsByUser(final String userCode) {  
        if (userCode == null)  
            return null;  
  
            List<org.activiti.extsys.entity.Group> bGroups = accountManagerService.getGroupListByUserId(userCode);
              
            List<Group> gs = null;
            gs = ActivitiUtils.toActivitiGroups(bGroups);  
            return gs;  
              
    }  
  
    @Override  
    public List<User> findUserByQueryCriteria(UserQueryImpl query, Page page) {  
    	throw new RuntimeException("not implement method."); 
    }  
  
    @Override  
    public IdentityInfoEntity findUserInfoByUserIdAndKey(String userId, String key) {  
        throw new RuntimeException("not implement method.");  
    }
  
    @Override  
    public List<String> findUserInfoKeysByUserIdAndType(String userId, String type) {  
        throw new RuntimeException("not implement method.");  
    }  
  
    @Override  
    public long findUserCountByQueryCriteria(UserQueryImpl query) {  
        throw new RuntimeException("not implement method.");  
    }  
}  