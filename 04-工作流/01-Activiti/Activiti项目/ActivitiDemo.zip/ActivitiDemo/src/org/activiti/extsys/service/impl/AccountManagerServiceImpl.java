package org.activiti.extsys.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.activiti.extsys.dao.AccountManagerMapper;
import org.activiti.extsys.entity.Group;
import org.activiti.extsys.entity.User;
import org.activiti.extsys.service.AccountManagerService;
import org.springframework.stereotype.Service;

@Service("accountManagerService")
public class AccountManagerServiceImpl implements AccountManagerService {
	@Resource
    public AccountManagerMapper accountManagerMapper;

	@Override
	public Group getGroupByGroupId(String groupCode) {
		return accountManagerMapper.getGroupByGroupId(groupCode);
	}

	@Override
	public User getUserByUserId(String userCode) {
		return accountManagerMapper.getUserByUserId(userCode);
	}

	@Override
	public List<Group> getGroupListByUserId(String userCode) {
		return accountManagerMapper.getGroupListByUserId(userCode);
	}
}
