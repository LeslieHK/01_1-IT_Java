package org.activiti.service.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.activiti.engine.HistoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.activiti.util.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Activitie 任务
 * @author 陈少钦
 * @date 2017 儿童节
 */
@Controller  
@Scope("prototype")   
@RequestMapping("/task")
public class TaskController {
    @Autowired
    protected RuntimeService runtimeService;
    @Autowired
    HistoryService historyService;
    @Autowired
    TaskService taskService;
    
    /**
	  * 获取待办任务
	  * 1)因为是任务查询，所以从processEngine中应该得到TaskService
	  * 2)使用TaskService获取到任务查询对象TaskQuery
	  * 3)为查询对象添加查询过滤条件，使用taskAssignee指定任务的办理者（即查询指定用户的代办任务），同时可以添加分页排序等过滤条件
	  * 4)调用list方法执行查询，返回办理者为指定用户的任务列表
	  * 5)任务ID、名称、办理人、创建时间可以从act_ru_task表中查到。
	  * @return
	  */
	@RequestMapping(value="get_todo_task/{assignee}")
	@ResponseBody
	public List<Map<String, String>> getTodoTask(@PathVariable("assignee") String assignee, HttpServletRequest request){
		List<Map<String, String>> taskList = new ArrayList<Map<String, String>>();
		
		// 1、用户ID为空
		if(CommonUtil.isEmpty(assignee)) return taskList;
		
		// 2、通过taskQuery获取列表
		List<Task> list = taskService.createTaskQuery()
//			.or()
//			.taskAssignee(assignee)/**指定个人任务查询，指定办理人*/
//          .taskCandidateUser(assignee)/**指定候选人 */
//          .endOr()
			.or()
            .taskCandidateOrAssigned(assignee)
            .taskCandidateGroup("engineeringa")
            .endOr()
//          .taskCandidateUser(candidateUser)/**组任务的办理人查询*/  
//          .processDefinitionId(processDefinitionId)/**使用请假流程ID查询*/  
//          .processInstanceId(processInstanceId)/**使用流程实例ID查询*/  
//          .executionId(executionId)/**使用执行对象ID查询*/  
            .orderByTaskCreateTime().asc()/**使用创建时间的升序排列*/  
//          .singleResult()/**返回惟一结果集*/  
//          .count()/**返回结果集的数量*/  
//          .listPage(firstResult, maxResults);/**分页查询*/  
            .list();/**返回列表*/
  
		// 3、转化成List<Map<String, String>>
        if(null != list && list.size() > 0){
            for(Task task : list){  
//                System.out.println("任务ID:"+task.getId());  
//                System.out.println("任务名称:"+task.getName());  
//                System.out.println("任务的创建时间:"+task.getCreateTime());  
//                System.out.println("任务的办理人:"+task.getAssignee());  
//                System.out.println("流程实例ID："+task.getProcessInstanceId());  
//                System.out.println("执行对象ID:"+task.getExecutionId());  
//                System.out.println("请假流程ID:"+task.getProcessDefinitionId());  
//                System.out.println("########################################################"); 
            	
            	// 历史流程实例：获取发起人
            	HistoricProcessInstance hisProcessInst = historyService.createHistoricProcessInstanceQuery().processInstanceId(task.getProcessInstanceId()).singleResult();
            	// 运行中流程实例：获取流程定义名称和流程实例ID
            	ProcessInstance processInst = runtimeService.createProcessInstanceQuery().processInstanceId(task.getProcessInstanceId()).singleResult();
            	
            	Map<String, String> map = new HashMap<String, String>();
            	map.put("id", task.getId());
            	map.put("name", task.getName());
            	map.put("createTime", task.getCreateTime().toString());
            	map.put("assignee", task.getAssignee());
            	map.put("processName", processInst.getProcessDefinitionName());
            	map.put("startUserId", hisProcessInst.getStartUserId());
            	map.put("processDefinitionKey", processInst.getProcessDefinitionKey());
            	map.put("processInstanceId", processInst.getProcessInstanceId());
            	map.put("title", CommonUtil.obj2Str(taskService.getVariables(task.getId()).get("title")));
            	
            	taskList.add(map);
            }  
        }  
		return taskList;
	}
	
}
