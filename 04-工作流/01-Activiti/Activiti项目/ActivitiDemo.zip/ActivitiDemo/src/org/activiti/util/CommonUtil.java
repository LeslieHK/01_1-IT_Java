package org.activiti.util;

/**
 * Activitie通用工具类
 * @author 陈少钦
 * @since 2017 儿童节
 */
public class CommonUtil {

	/**
	 * 判断字符串是否为空
	 * @param str
	 * @return
	 */
	public static boolean isEmpty(String str){
		return null == str || str.trim().equals("") || str.trim().equals("undefined") || str.trim().equals("null");  
	}
	
	/**
	 * 对象转化成字符串
	 * @param str
	 * @return
	 */
	public static String obj2Str(Object obj){
		return null == obj ? "" : obj.toString();  
	}
}
