package org.activiti.extsys.service;

import java.util.List;

import org.activiti.extsys.entity.Group;
import org.activiti.extsys.entity.User;

public interface AccountManagerService {

	public Group getGroupByGroupId(String groupCode);
	public User getUserByUserId(String userCode);
	public List<Group> getGroupListByUserId(String userCode);
}
