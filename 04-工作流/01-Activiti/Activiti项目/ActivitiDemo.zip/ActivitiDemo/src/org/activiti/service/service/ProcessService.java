package org.activiti.service.service;

import java.util.List;

public interface ProcessService {
	public List<Process> getProcessList();
}
