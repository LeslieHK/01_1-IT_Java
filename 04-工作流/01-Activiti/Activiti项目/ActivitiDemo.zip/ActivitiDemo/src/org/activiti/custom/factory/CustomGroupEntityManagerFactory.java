package org.activiti.custom.factory;

import org.activiti.custom.manager.CustomGroupEntityManager;
import org.activiti.engine.impl.interceptor.Session;
import org.activiti.engine.impl.interceptor.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 用户组管理工厂类
 * @author 陈少钦
 * @date 2017/06/05
 */
public class CustomGroupEntityManagerFactory implements SessionFactory {  
    private CustomGroupEntityManager groupEntityManager;  
  
    @Autowired  
    public void setGroupEntityManager(CustomGroupEntityManager groupEntityManager) {  
        this.groupEntityManager = groupEntityManager;  
    }  
  
    public Class<?> getSessionType() {  
        // 返回原始的GroupEntityManager类型  
        return CustomGroupEntityManager.class;  
    }  
  
    public Session openSession() {  
        // 返回自定义的GroupEntityManager实例  
        return groupEntityManager;  
    }  
}
