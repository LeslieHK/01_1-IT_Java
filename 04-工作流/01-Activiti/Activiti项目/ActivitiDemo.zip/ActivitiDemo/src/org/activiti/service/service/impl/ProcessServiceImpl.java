package org.activiti.service.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.activiti.service.dao.ProcessMapper;
import org.activiti.service.service.ProcessService;
import org.springframework.stereotype.Service;

@Service("processService")
public class ProcessServiceImpl implements ProcessService {
	@Resource
    public ProcessMapper processMapper;

	@Override
	public List<Process> getProcessList() {
		return processMapper.getProcessList();
	}
}
