package org.activiti.service.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.activiti.bpmn.converter.BpmnXMLConverter;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.editor.constants.ModelDataJsonConstants;
import org.activiti.editor.language.json.converter.BpmnJsonConverter;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.impl.util.json.JSONObject;
import org.activiti.engine.repository.Model;
import org.activiti.util.CommonUtil;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * Activitie 模型管理
 * @author 陈少钦
 * @date 2017 儿童节
 */
@Controller  
@Scope("prototype")   
@RequestMapping("/model")  
public class ModelController {
	@Autowired
    RepositoryService repositoryService;
    
	/** 
	  * 创建模型
	  * 1.设置对象值
	  * 2.存储模型对象（表act_re_model）
	  * 3.存储模型对象基础数据（表act_ge_bytearray）
	  * 4.跳转到ActivitiModeler编辑流程图，存储流程图片和流程定义等（表act_ge_bytearray）
	  * @return 
	  */  
	@RequestMapping(value = "create_model")  
	public void createModel(String description, String name, String key, HttpServletRequest request, HttpServletResponse response){
		response.setContentType("text/html;charset=utf-8");
		
		// 判断名称和标识是否为空
	    if(CommonUtil.isEmpty(name) || CommonUtil.isEmpty(key)){
	    	try {
	    		response.getWriter().write("模型名称或标识不能为空");
			} catch (IOException e) {
				e.printStackTrace();
			}
	    	return;
        }
		 
	    try {
	    	ObjectMapper objectMapper = new ObjectMapper();
	        ObjectNode editorNode = objectMapper.createObjectNode();
	        editorNode.put("id", "canvas");
	        editorNode.put("resourceId", "canvas");
	        ObjectNode stencilSetNode = objectMapper.createObjectNode();
	        stencilSetNode.put("namespace", "http://b3mn.org/stencilset/bpmn2.0#");
	        editorNode.put("stencilset", stencilSetNode);
	         
	        Model modelData = repositoryService.newModel();
	        ObjectNode modelObjectNode = objectMapper.createObjectNode();
	        modelObjectNode.put(ModelDataJsonConstants.MODEL_NAME, name);
	        modelObjectNode.put(ModelDataJsonConstants.MODEL_REVISION, 1);
	        description = StringUtils.defaultString(description);
	        modelObjectNode.put(ModelDataJsonConstants.MODEL_DESCRIPTION, description);
	        modelData.setMetaInfo(modelObjectNode.toString());
	        modelData.setName(name);
	        modelData.setKey(StringUtils.defaultString(key));

	        repositoryService.saveModel(modelData);
	        repositoryService.addModelEditorSource(modelData.getId(), editorNode.toString().getBytes("utf-8"));
	        
	        response.sendRedirect(request.getContextPath() + "/modeler.html?modelId=" + modelData.getId());
	    } catch (Exception e) {
	    	try {
	    		response.getWriter().write("创建模型失败：" + e.getCause());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
	    }
	}  
	
	/**
	  * 查询模型列表
	  * 1.使用activiti提供的接口，创建Model查询
	  * 2.指定排序字段和排序方式
	  * 3.返回集合list
	  * @return
	  */
    @RequestMapping(value="get_model_list")
    @ResponseBody
	public List<Model> getModelList(){
    	// 按名称升序获取模型列表
		List<Model> resultList =  repositoryService.createModelQuery().orderByModelName().asc().list();
		return resultList;
    }
	
	/**
	  * 删除模型
	  * 1.按模型ID删除
	  * 2、多个ID用逗号分隔
	  * @return
	  */
	@RequestMapping(value="del_model/{ids}")
	@ResponseBody
	public String delModel(@PathVariable("ids") String ids, HttpServletRequest request){
		JSONObject result = new JSONObject();
		
		if(CommonUtil.isEmpty(ids)){
			result.put("msg", "模型ID不能为空");
			result.put("type", "error");
		} else{
			for(String id : ids.split(",")){
				repositoryService.deleteModel(id);
			}
			result.put("msg", "删除成功");
			result.put("type", "success");
		}
		
		return result.toString();
	}
	
	/**
	  * 导出模型的xml文件
	  * 1.获取节点信息
	  * 2.转换为xml数据
	  * 3.写入流中输出
	  */
	@RequestMapping(value="export_model/{modelId}")
	public void export_model(@PathVariable("modelId") String modelId, HttpServletRequest request, HttpServletResponse response){
		response.setCharacterEncoding("UTF-8");  
		response.setContentType("application/json; charset=utf-8");  
		PrintWriter out = null;
        try {
        	out = response.getWriter();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
		try {
			Model modelData = repositoryService.getModel(modelId);
	        BpmnJsonConverter jsonConverter = new BpmnJsonConverter();
	        //获取节点信息
	        byte[] arg0 = repositoryService.getModelEditorSource(modelData.getId());
	        JsonNode editorNode = new ObjectMapper().readTree(arg0);
	        //将节点信息转换为xml
	        BpmnModel bpmnModel = jsonConverter.convertToBpmnModel(editorNode);
	        BpmnXMLConverter xmlConverter = new BpmnXMLConverter();
	        byte[] bpmnBytes = xmlConverter.convertToXML(bpmnModel);

	        ByteArrayInputStream in = new ByteArrayInputStream(bpmnBytes);
	        IOUtils.copy(in, out);
//	        String filename = bpmnModel.getMainProcess().getId() + ".bpmn20.xml";
	        String filename = modelData.getKey() + ".bpmn20.xml";
	        response.setHeader("Content-Disposition", "attachment; filename=" + java.net.URLEncoder.encode(filename, "UTF-8"));
	        response.flushBuffer();
		} catch (Exception e){
	        out.write("未找到对应数据");
	        e.printStackTrace();
	    }
	}
	
	/**
	  * 部署
	  * 1.根据modelId获取模型信息
	  * 2.转换为xml对象
	  * 3.部署对象以模型对象的名称命名
	  * 4.部署转换出来的xml对象
	  */
	@RequestMapping(value = "deploy_model/{modelId}")
	@ResponseBody
	public String deployModel(@PathVariable("modelId") String modelId, HttpServletRequest request) {
		JSONObject result = new JSONObject();
		
		if(CommonUtil.isEmpty(modelId)){
			result.put("msg", "模型ID不能为空");
			result.put("type", "error");
			return result.toString();
		}
		
	    try {
	    	Model modelData = repositoryService.getModel(modelId);
	        ObjectNode modelNode = (ObjectNode) new ObjectMapper().readTree(repositoryService.getModelEditorSource(modelData.getId()));
	        ((ObjectNode) modelNode.get("properties")).put("process_id", modelData.getKey()).put("name", modelData.getName());
	        
	        byte[] bpmnBytes = null;
	        BpmnModel model = new BpmnJsonConverter().convertToBpmnModel(modelNode);
	        bpmnBytes = new BpmnXMLConverter().convertToXML(model);
	        String processName = modelData.getName() + ".bpmn20.xml";
	        //Deployment deployment = 
	        repositoryService.createDeployment().name(modelData.getName()).addString(processName, new String(bpmnBytes,"utf-8")).deploy();
	        result.put("msg", "部署成功");
	        result.put("type", "success");
	    } catch (Exception e) {
	        result.put("msg", "部署失败："+e.getCause());
	        result.put("type", "error");
	        e.printStackTrace();
	    }
	    return result.toString();
	}

}
