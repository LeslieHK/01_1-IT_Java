package org.activiti.service.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.activiti.engine.HistoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.task.IdentityLink;
import org.activiti.util.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Activitie 历史记录
 * @author 陈少钦
 * @date 2017 儿童节
 */
@Controller  
@Scope("prototype")   
@RequestMapping("/his")
public class HisController {
    @Autowired
    protected RuntimeService runtimeService;
    @Autowired
    HistoryService historyService;
    @Autowired
    TaskService taskService;
    
    /**
	  * 获取个人已办任务
	  * @return
	  */
	@RequestMapping(value="get_his_task/{assignee}")
	@ResponseBody
	public List<Map<String, String>> getHisTask(@PathVariable("assignee") String assignee, HttpServletRequest request){
		List<Map<String, String>> taskList = new ArrayList<Map<String, String>>();

		// 1、用户ID为空
		if(CommonUtil.isEmpty(assignee)) return taskList;
		
		// 2、通过historicTaskInstanceQuery获取列表
		// 不加 finished() 会将当前执行的任务也加进去
		List<HistoricTaskInstance> list = historyService.createHistoricTaskInstanceQuery().finished().
				taskAssignee(assignee)./**指定个人任务查询，指定办理人*/
				orderByTaskCreateTime().asc().
				list();
  
        
        if(list!=null && list.size()>0){
            for(HistoricTaskInstance task:list){  
//                System.out.println("任务ID:"+task.getId());  
//                System.out.println("任务名称:"+task.getName());  
//                System.out.println("任务的创建时间:"+task.getCreateTime());  
//                System.out.println("任务的办理人:"+task.getAssignee());  
//                System.out.println("流程实例ID："+task.getProcessInstanceId());  
//                System.out.println("执行对象ID:"+task.getExecutionId());  
//                System.out.println("请假流程ID:"+task.getProcessDefinitionId());  
//                System.out.println("########################################################");
            	
            	// 任务对应的流程实例
            	HistoricProcessInstance hisProcessInst = historyService.createHistoricProcessInstanceQuery().processInstanceId(task.getProcessInstanceId()).singleResult();
            	// 任务对应的变量
            	List<HistoricVariableInstance> varsList = historyService.createHistoricVariableInstanceQuery().processInstanceId(task.getProcessInstanceId()).list();
            	
            	Map<String, String> map = new HashMap<String, String>();
            	map.put("id", task.getId());
            	map.put("name", task.getName());
            	map.put("createTime", task.getCreateTime().toString());
            	map.put("assignee", task.getAssignee());
            	map.put("processName", hisProcessInst.getProcessDefinitionName());
            	map.put("startUserId", hisProcessInst.getStartUserId());
            	map.put("processInstanceId", task.getProcessInstanceId());
            	// 标题 
    			for(HistoricVariableInstance hisVarIns : varsList){
    				if("title".equals(hisVarIns.getVariableName())){
    					map.put("title", CommonUtil.obj2Str(hisVarIns.getValue()));
    					break;
    				}
    			}
            	
            	taskList.add(map);
            }  
        }  
        return taskList;
	}
	
	/**
	 * 查询历史流程实例
	 * @return
	 */
	@RequestMapping(value="get_his_process_instance")
	@ResponseBody
	public List<Map<String, String>> getHisProcessInstance(){	
		List<HistoricProcessInstance> hisProcessInstList = historyService
				.createHistoricProcessInstanceQuery()
				.finished()
				.list();
		
		// 转化成List<Map<String, String>>
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		for(HistoricProcessInstance processInst : hisProcessInstList){
			// 实例对应的变量
			List<HistoricVariableInstance> varsList = historyService.createHistoricVariableInstanceQuery().processInstanceId(processInst.getId()).list();
			
			Map<String, String> map = new HashMap<String, String>();
			map.put("processDefinitionKey", processInst.getProcessDefinitionKey());
			map.put("processDefinitionName", processInst.getProcessDefinitionName());
			map.put("startTime", CommonUtil.obj2Str(processInst.getStartTime()));
			map.put("endTime", CommonUtil.obj2Str(processInst.getEndTime()));
			map.put("id", processInst.getId());
			// 标题 
			for(HistoricVariableInstance hisVarIns : varsList){
				if("title".equals(hisVarIns.getVariableName())){
					map.put("title", CommonUtil.obj2Str(hisVarIns.getValue()));
					break;
				}
			}
			
			list.add(map);
		}
		
		return list;
	}
	
	/**
	 * 获取流程实例审批节点
	 * @return
	 */
	@RequestMapping(value="get_his_process_instance_nodes/{processInstId}/{taskId}")
	@ResponseBody
	public List<Map<String, String>> getHisProcessInstanceNodes(@PathVariable("processInstId") String processInstId, @PathVariable("taskId") String taskId){
		if(CommonUtil.isEmpty(processInstId))
			processInstId = historyService.createHistoricTaskInstanceQuery().taskId(taskId).singleResult().getProcessInstanceId();
		
		// 任务列表
		List<HistoricTaskInstance> list = historyService
			.createHistoricTaskInstanceQuery()
			//.finished()
			.processInstanceId(processInstId)
			.list();

		List<Map<String, String>> hisTaskList = new ArrayList<Map<String, String>>();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		if(list!=null && list.size()>0){
			for(HistoricTaskInstance hisTask : list){
				// 任务信息
				Map<String, String> hisTaskMap = new HashMap<String, String>();
				hisTaskMap.put("name", hisTask.getName());
				hisTaskMap.put("startTime", sdf.format(hisTask.getStartTime()));
				
				// 任务办理人：
				// 1、任务已办理
				// 2、任务正在处理中，判断是assignee还是用candidate
				String candidate = "";
				List<IdentityLink> identityLinkList = taskService.getIdentityLinksForTask(taskId);
				for(IdentityLink identityLink : identityLinkList){
					candidate += (identityLink.getUserId() + "  ");
				}
				hisTaskMap.put("assignee", CommonUtil.isEmpty(hisTask.getAssignee()) ? candidate : hisTask.getAssignee());
				
				// 时间差
				if(null != hisTask.getEndTime()){
					hisTaskMap.put("endTime", sdf.format(hisTask.getEndTime()));
					
					long diff = (hisTask.getEndTime().getTime() - hisTask.getStartTime().getTime()) / (1000*60);
					String totalTime = "";
					if(diff > (60*24)){
						totalTime += (diff / (60*24) + "天");
						diff = diff % (60*24);
					}
					if(diff > 60){
						totalTime += (diff / 60 + "小时");
						diff = diff % 60;
					}
					if(diff > 00){
						totalTime += (diff + "分钟");
					}
					if(totalTime == "") totalTime = "0分钟";
					hisTaskMap.put("totalTime", totalTime);
				} else{
					hisTaskMap.put("endTime", "");
					hisTaskMap.put("totalTime", "");
				}
				
				// 意见
				String opinion = "";//(String) taskService.getVariable(hisTask.getId(), "opinion");
				List<HistoricVariableInstance> varList = historyService.createHistoricVariableInstanceQuery().taskId(hisTask.getId()).list();
				for (HistoricVariableInstance variableInstance : varList) {
					if("opinion".equals(variableInstance.getVariableName())){
						opinion = CommonUtil.obj2Str(variableInstance.getValue());
						opinion = CommonUtil.obj2Str(opinion);
						break;
					}
				}
				hisTaskMap.put("opinion", opinion);

				hisTaskList.add(hisTaskMap);
			}
		}
		return hisTaskList;
	}
	
}
