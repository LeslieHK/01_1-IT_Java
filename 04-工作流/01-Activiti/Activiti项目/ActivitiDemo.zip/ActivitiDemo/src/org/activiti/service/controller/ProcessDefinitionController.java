package org.activiti.service.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipInputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.activiti.engine.RepositoryService;
import org.activiti.engine.impl.util.json.JSONObject;
import org.activiti.engine.repository.DeploymentBuilder;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.util.CommonUtil;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

/**
 * Activitie 流程定义管理
 * @author 陈少钦
 * @date 2017 儿童节
 */
@Controller  
@Scope("prototype")   
@RequestMapping("/process_definition")  
public class ProcessDefinitionController {
	@Autowired
    RepositoryService repositoryService;
    
    /**
     * 查询所有的流程定义
     */
    @RequestMapping(value="get_process_definition")
	@ResponseBody
    public List<Map<String, Object>> getProcessDefinition() {
    	List<ProcessDefinition> list = repositoryService.createProcessDefinitionQuery()// 创建一个流程定义的查询
		/**
		 * 指定查询条件，where条件
		 */
		// .deploymentId(deploymentId) //使用部署对象ID查询
		// .processDefinitionId(processDefinitionId)//使用流程定义ID查询
		// .processDefinitionNameLike(processDefinitionNameLike)//使用流程定义的名称模糊查询

		/**
		 * 排序 
		 */
		//.orderByProcessDefinitionVersion().asc()
    	.latestVersion()//只显示最新版本
		.orderByProcessDefinitionName().asc()

    	/**
    	 * 返回的结果集 
    	 */
    	.list();// 返回一个集合列表，封装流程定义
    	// .singleResult();//返回惟一结果集
    	// .count();//返回结果集数量
    	// .listPage(firstResult, maxResults);//分页查询
    	
//    	if (list != null && list.size() > 0) {
//    		for (ProcessDefinition pd : list) {
//    			System.out.println("流程定义ID:" + pd.getId());// 流程定义的key+版本+随机生成数
//    			System.out.println("流程定义的名称:" + pd.getName());// 对应helloworld.bpmn文件中的name属性值
//    			System.out.println("流程定义的key:" + pd.getKey());// 对应helloworld.bpmn文件中的id属性值
//    			System.out.println("流程定义的版本:" + pd.getVersion());// 当流程定义的key值相同的相同下，版本升级，默认1
//    			System.out.println("资源名称bpmn文件:" + pd.getResourceName());
//    			System.out.println("资源名称png文件:" + pd.getDiagramResourceName());
//    			System.out.println("部署对象ID：" + pd.getDeploymentId());
//    		}
//    	}
    	
    	// 2、转化
    	List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();
    	for (ProcessDefinition pd : list) {
    		Map<String, Object> map = new HashMap<String, Object>();
    		map.put("id", pd.getId());
    		map.put("name", pd.getName());
    		map.put("key", pd.getKey());
    		map.put("version", pd.getVersion());
    		map.put("resourceName", pd.getResourceName());
    		map.put("diagramResourceName", pd.getDiagramResourceName());
    		map.put("deploymentId", pd.getDeploymentId());
    		map.put("status", pd.isSuspended() ? "suspended" : "active");
    		
    		resultList.add(map);
		}
    	
    	return resultList;
    }
    
    /**
	  * 删除流程定义
	  * 1.通过流程定义标识删除流程定义
	  * @return
	  */
	@RequestMapping(value="del_process_definition/{processDefinitionKey}")
	@ResponseBody
	public String delProcessDefinition(@PathVariable("processDefinitionKey") String keys, HttpServletRequest request){
		 JSONObject result = new JSONObject();
		 
		 // 1、判断是否为空
		 if(CommonUtil.isEmpty(keys)){
			 result.put("msg", "流程标识不能为空");
			 result.put("type", "error");
			 return result.toString();
		 }
		 
		 // 2、删除
		 for(String key : keys.split(",")){
			 // 先使用流程定义的key查询流程定义，查询出所有的版本  
			 List<ProcessDefinition> list = repositoryService.createProcessDefinitionQuery()  
					 .processDefinitionKey(key)// 使用流程定义的key查询  
			         .list();  
			 // 遍历，获取每个流程定义的部署ID  
			 if (list != null && list.size() > 0) {  
				 for (ProcessDefinition pd : list) {  
					 // 获取部署ID
					 String deploymentId = pd.getDeploymentId();
					 
					 // 不带级联的删除， 只能删除没有启动的流程，如果流程启动，就会抛出异常  
					 // processEngine.getRepositoryService().deleteDeployment(deploymentId);  
					 // 级联删除 不管流程是否启动，都可以删除 
					 repositoryService.deleteDeployment(deploymentId, true);  
				 }  
			 }  
		 }
		 
		 result.put("msg", "删除成功");
		 result.put("type", "success");
		 return result.toString();
	}
	
	/** 
	  * 获取流程定义png文件的输入流 
	  *  
	  * @throws Exception 
	  */  
	@RequestMapping(value="get_process_definition_img/{processDefinitionId}")
	public void getPDImg(@PathVariable("processDefinitionId") String id, HttpServletRequest request, HttpServletResponse response) {  
        InputStream pngInputStream = repositoryService.getProcessDiagram(id);  
        
        // 输出资源内容到相应对象
        byte[] b = new byte[1024];
        int len;
        try {
        	while ((len = pngInputStream.read(b, 0, 1024)) != -1) {
        		response.getOutputStream().write(b, 0, len);
        	}
        } catch (IOException e) {
        	e.printStackTrace();
        }
	}  
	
    /** 
	  * 挂起流程定义 
	  * 
	  * @throws Exception 
	  */  
    @RequestMapping(value="suspend_process_definition/{processDefinitionId}")
	@ResponseBody
	public String suspendProcessDefinition(@PathVariable("processDefinitionId") String id, HttpServletRequest request, HttpServletResponse response) {
		JSONObject result = new JSONObject();
	    
		ProcessDefinition pd = null;
		try{
			pd = repositoryService.getProcessDefinition(id);
		} catch (Exception e) {
			result.put("msg", "流程定义为空");
			result.put("type", "error");
			
			e.printStackTrace();
			return result.toString();
		}
		
		if(pd.isSuspended()){
			result.put("msg", "流程定义处于挂起状态");
			result.put("type", "error");
		} else{
			repositoryService.suspendProcessDefinitionById(id, true, null);
			result.put("msg", "流程定义挂起成功");
			result.put("type", "success");
		}
		return result.toString();
    }
    
    /** 
	  * 激活流程定义 
	  * 
	  * @throws Exception 
	  */  
    @RequestMapping(value="active_process_definition/{processDefinitionId}")
	@ResponseBody
	public String activeProcessDefinition(@PathVariable("processDefinitionId") String id, HttpServletRequest request, HttpServletResponse response) {
		JSONObject result = new JSONObject();
	    
		ProcessDefinition pd = null;
		try{
			pd = repositoryService.getProcessDefinition(id);
		} catch (Exception e) {
			result.put("msg", "流程定义为空");
			result.put("type", "error");
			
			e.printStackTrace();
			return result.toString();
		}
		
		if(!pd.isSuspended()){
			result.put("msg", "流程定义处于激活状态");
			result.put("type", "error");
		} else{
			repositoryService.activateProcessDefinitionById(id, true, null);
			result.put("msg", "流程定义激活成功");
			result.put("type", "success");
		}
		return result.toString();
    }
    
    /**
	  * 导入流程
	  * 1.支持格式：xml、zip、tar
	  */
    @RequestMapping(value = "import_process_definition")
	@ResponseBody
	public void importProcessDefinition(MultipartFile processDefinitionFile, HttpServletRequest request, HttpServletResponse response) {
        response.setContentType("text/html;charset=utf-8");
		PrintWriter out = null;
		try {
			out = response.getWriter();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		// 判断文件是否为空
		if(null == processDefinitionFile) {out.print("文件不能为空");return;}
		String path = request.getSession().getServletContext().getRealPath("upload");  
		String fileName = processDefinitionFile.getOriginalFilename();  
		File targetFile = new File(path, fileName);  
		if(!targetFile.exists()){  
			targetFile.mkdirs();  
		}  
 
		// 保存文件到项目目录下  
		try {  
			processDefinitionFile.transferTo(targetFile);  
		} catch (Exception e) {  
			e.printStackTrace();  
		}  
       
		// 导入流程定义
		try {
			// 得到输入流（字节流）对象
			InputStream fileInputStream = new FileInputStream(targetFile);
			
//			StreamSource xmlSource = new InputStreamSource(fileInputStream);
//			BpmnModel model = new BpmnXMLConverter().convertToBpmnModel(xmlSource, false, false, "utf-8");
			
			// 文件的扩展名
			String extension = FilenameUtils.getExtension(fileName);
			// zip或者bar类型的文件用ZipInputStream方式部署
			DeploymentBuilder deployment = repositoryService.createDeployment();
			if (extension.equals("zip") || extension.equals("bar")) {
				ZipInputStream zip = new ZipInputStream(fileInputStream);
				deployment.addZipInputStream(zip);
			} else if (extension.equals("xml")){
				// xml类型的文件
				deployment.addInputStream(fileName, fileInputStream);
			}
			deployment.deploy();
        } catch (Exception e) {
        	out.print(fileName + " error on deploy process, because of file input stream");
        }
		
		
		out.print("导入成功");
   }
}
