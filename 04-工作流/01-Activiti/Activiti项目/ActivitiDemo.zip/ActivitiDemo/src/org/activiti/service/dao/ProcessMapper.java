package org.activiti.service.dao;

import java.util.List;

public interface ProcessMapper {

	List<Process> getProcessList();
	
}