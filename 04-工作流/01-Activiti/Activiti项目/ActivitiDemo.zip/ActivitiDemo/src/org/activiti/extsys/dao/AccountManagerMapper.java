package org.activiti.extsys.dao;

import java.util.List;

import org.activiti.extsys.entity.Group;
import org.activiti.extsys.entity.User;

public interface AccountManagerMapper {

	// 获取用户组
	public Group getGroupByGroupId(String groupCode);
	// 获取用户
	public User getUserByUserId(String userCode);
	// 通过用户ID获取用户组
	public List<Group> getGroupListByUserId(String userCode);
}
