package org.activiti.custom.factory;

import org.activiti.custom.manager.CustomUserEntityManager;
import org.activiti.engine.impl.interceptor.Session;
import org.activiti.engine.impl.interceptor.SessionFactory;
import org.activiti.engine.impl.persistence.entity.UserIdentityManager;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 用户管理工厂类
 * @author 陈少钦
 * @date 2017/06/05
 */
public class CustomUserEntityManagerFactory implements SessionFactory {
    private CustomUserEntityManager userEntityManager;

    @Autowired
    public void setUserEntityManager(CustomUserEntityManager userEntityManager) {
        this.userEntityManager = userEntityManager;
    }

    public Class<?> getSessionType() {
        // 返回原始的UserManager类型
        return UserIdentityManager.class;
    }
    public Session openSession() {
        // 返回自定义的UserManager实例
        return userEntityManager;
    }
}