package org.activiti.service.entity;

public class Process {
	private String ID_;
	private String KEY_;
	private String NAME_;
	private String VERSION_;
	private String DESCRIPTION_;
	public String getID_() {
		return ID_;
	}
	public void setID_(String iD_) {
		ID_ = iD_;
	}
	public String getKEY_() {
		return KEY_;
	}
	public void setKEY_(String kEY_) {
		KEY_ = kEY_;
	}
	public String getNAME_() {
		return NAME_;
	}
	public void setNAME_(String nAME_) {
		NAME_ = nAME_;
	}
	public String getVERSION_() {
		return VERSION_;
	}
	public void setVERSION_(String vERSION_) {
		VERSION_ = vERSION_;
	}
	public String getDESCRIPTION_() {
		return DESCRIPTION_;
	}
	public void setDESCRIPTION_(String dESCRIPTION_) {
		DESCRIPTION_ = dESCRIPTION_;
	}
}
