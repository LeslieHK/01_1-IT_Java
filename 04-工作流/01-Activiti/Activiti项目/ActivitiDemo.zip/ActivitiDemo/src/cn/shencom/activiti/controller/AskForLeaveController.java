package cn.shencom.activiti.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.activiti.engine.ActivitiTaskAlreadyClaimedException;
import org.activiti.engine.HistoryService;
import org.activiti.engine.IdentityService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.impl.util.json.JSONObject;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.activiti.util.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

@Controller  
@Scope("prototype")   
@RequestMapping("/ask_for_leave")  
public class AskForLeaveController {
	@Autowired
    RepositoryService repositoryService;
	@Autowired
	IdentityService identityService;
	@Autowired
    protected RuntimeService runtimeService;
	@Autowired
	TaskService taskService;
	@Autowired
    HistoryService historyService;
	
    /**
	  * 请假流程发起页面
	  * @return
	  */
	@RequestMapping(value="start_page")
	public void start_page(HttpServletResponse response, HttpServletRequest request) throws Exception {
		String assignee = "wangwu";
		String processDefinitionName = repositoryService.createProcessDefinitionQuery().processDefinitionKey("AskForLeave").latestVersion().singleResult().getName();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		String date = sdf.format(new Date());
		
		String processInstName = assignee + "的" + processDefinitionName + "-" + date;
		request.setAttribute("title", processInstName);
		request.setAttribute("taskId", "");
		request.setAttribute("hisTaskList", new ArrayList<Map<String, String>>());
		request.setAttribute("cnt", 0);
		request.getRequestDispatcher("/activiti-process/ask_for_leave.jsp").forward(request, response);
	}
	
	/**
	  * 启动流程实例
	  * @return
	  */
	@RequestMapping(value="start_process_instance")
	@ResponseBody
	public String startProcessInstance(String title, String type, String startTime, 
			String endTime, String reason, 
			HttpServletRequest request){

		// 转成JSON格式
		JSONObject result = new JSONObject();
				
		try{
	        // 创建流程变量
	        Map<String,Object> variables = new HashMap<String,Object>();
	        variables.put("title", title);
	        variables.put("type", type);
	        variables.put("startTime", startTime);
	        variables.put("endTime", endTime);
	        variables.put("reason", reason);
	        
	        // 发起人
	        identityService.setAuthenticatedUserId("wangwu");
	        // 使用请假流程的key启动流程实例，key对应leave.bpmn文件中id的属性值，使用key值启动，默认是按照最新版本的请假流程启动
			ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("AskForLeave", variables);

			//根据流程ID获取当前任务：
			Task task = taskService.createTaskQuery().processInstanceId(processInstance.getProcessInstanceId()).singleResult();
			taskService.complete(task.getId());
			
			result.put("msg", "启动流程成功");
			result.put("type", "success");
		} catch(Exception e){
			e.printStackTrace();
			result.put("msg", "启动流程出错："+e.getMessage());
			result.put("type", "error");
		}
		
		return result.toString();
	}
	
	/**
     * 任务办理
     * @return
     */
	@RequestMapping(value="task_manage/{taskId}/{assignee}")
	public void taskManage(@PathVariable("taskId")String taskId, @PathVariable("assignee")String assignee, 
			HttpServletResponse response, HttpServletRequest request) throws Exception {
		// 流程实例ID
		String processInstId = taskService.createTaskQuery().taskId(taskId).singleResult().getProcessInstanceId();
		// 变量
		Map<String, Object> variables = taskService.getVariables(taskId);
		String title = CommonUtil.obj2Str(variables.get("title"));
		String type = CommonUtil.obj2Str(variables.get("type"));
		String startTime = CommonUtil.obj2Str(variables.get("startTime"));
		String endTime = CommonUtil.obj2Str(variables.get("endTime"));
		String reason = CommonUtil.obj2Str(variables.get("reason"));
		MultipartFile file = (MultipartFile) variables.get("relevantFile");
		System.out.println(null == file);
		
		request.setAttribute("title", title);
		request.setAttribute("type", type);
		request.setAttribute("startTime", startTime);
		request.setAttribute("endTime", endTime);
		request.setAttribute("reason", reason);
		request.setAttribute("processInsName", title);
		request.setAttribute("assignee", assignee);
		
		request.setAttribute("taskId", taskId);
		
		HistoricTaskInstance firstTask = historyService.createHistoricTaskInstanceQuery().processInstanceId(processInstId).orderByTaskCreateTime().asc().list().get(0);
		Task curTask = taskService.createTaskQuery().taskId(taskId).singleResult();
		
		if(firstTask.getTaskDefinitionKey().equals(curTask.getTaskDefinitionKey())){
			request.getRequestDispatcher("/activiti-process/ask_for_leave.jsp").forward(request, response);
		} else{
			request.getRequestDispatcher("/activiti-process/ask_for_leave_approve.jsp").forward(request, response);
		}
	}
	
	/**
     * 审批
     * @return
     */
	@RequestMapping(value="approve")
	@ResponseBody
	public String approve(String title, String type, String startTime, String assignee,
			String endTime, String reason, String taskId, String agree, String opinion, 
			HttpServletResponse response, HttpServletRequest request) throws Exception {

		// 转成JSON格式
		JSONObject result = new JSONObject();
		Map<String, Object> processVariables = taskService.getVariables(taskId);
		
		processVariables.put("title", title);
		processVariables.put("type", type);
		processVariables.put("startTime", startTime);
		processVariables.put("endTime", endTime);
		processVariables.put("reason", reason);
		processVariables.put("opinion", CommonUtil.obj2Str(opinion));
		if("true".equals(agree)){
			processVariables.put("pass", "true");
		} else{
			processVariables.put("pass", "false");
		}
		taskService.setVariableLocal(taskId, "opinion", opinion);
		
		// 设置办理人
		try{
			taskService.claim(taskId, assignee);
		} catch(ActivitiTaskAlreadyClaimedException e){
			e.printStackTrace();
			result.put("msg", "启动流程失败，该任务已被认领");
			result.put("type", "error");
			return result.toString();
		}
		
		taskService.complete(taskId, processVariables);
		result.put("msg", "启动流程成功");
		result.put("type", "success");
		return result.toString();
	}
	
	/**
	  * 启动流程实例
	  * @return
	  */
	@RequestMapping(value="start_process_instance_with_file")
	@ResponseBody
	public String startProcessInstanceWithFile(String title, String type, String startTime, 
			String endTime, String reason, 
			@RequestParam("relevantFile") MultipartFile file,
			HttpServletRequest request){

		// 转成JSON格式
		JSONObject result = new JSONObject();
				
		try{
	        // 创建流程变量
	        Map<String,Object> variables = new HashMap<String,Object>();
	        variables.put("title", title);
	        variables.put("type", type);
	        variables.put("startTime", startTime);
	        variables.put("endTime", endTime);
	        variables.put("reason", reason);
	        variables.put("relevantFile", file);
	        
	        // 发起人
	        identityService.setAuthenticatedUserId("wangwu");
	        // 使用请假流程的key启动流程实例，key对应leave.bpmn文件中id的属性值，使用key值启动，默认是按照最新版本的请假流程启动
			ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("AskForLeave", variables);

			//根据流程ID获取当前任务：
			Task task = taskService.createTaskQuery().processInstanceId(processInstance.getProcessInstanceId()).singleResult();
			taskService.complete(task.getId());
			
			result.put("msg", "启动流程成功");
			result.put("type", "success");
		} catch(Exception e){
			e.printStackTrace();
			result.put("msg", "启动流程出错："+e.getMessage());
			result.put("type", "error");
		}
		
		return result.toString();
	}
}
