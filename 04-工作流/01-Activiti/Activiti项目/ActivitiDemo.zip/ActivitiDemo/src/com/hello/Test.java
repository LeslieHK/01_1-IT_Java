package com.hello;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.activiti.editor.constants.ModelDataJsonConstants;
import org.activiti.engine.ActivitiException;
import org.activiti.engine.FormService;
import org.activiti.engine.HistoryService;
import org.activiti.engine.IdentityService;
import org.activiti.engine.ManagementService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngines;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.impl.util.json.JSONObject;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.Model;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;


@Controller  
@Scope("prototype")   
@RequestMapping("/user")  
public class Test  
{  
    @RequestMapping(value="/test",method=RequestMethod.GET)  
    public ModelAndView  goTest(String name,String password)  
    {  
        ModelAndView mov=new ModelAndView();  
        mov.setViewName("/test");  
        return mov;  
    }
    
    
    
    /**
     * 创建模型
     */
    @RequestMapping("create")
    public void create(HttpServletRequest request, HttpServletResponse response) {
        try {
        	ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();
        	 
        	RepositoryService repositoryService = processEngine.getRepositoryService();
        	 
            ObjectMapper objectMapper = new ObjectMapper();
            ObjectNode editorNode = objectMapper.createObjectNode();
            editorNode.put("id", "canvas");
            editorNode.put("resourceId", "canvas");
            ObjectNode stencilSetNode = objectMapper.createObjectNode();
            stencilSetNode.put("namespace", "http://b3mn.org/stencilset/bpmn2.0#");
            editorNode.put("stencilset", stencilSetNode);
            Model modelData = repositoryService.newModel();

            ObjectNode modelObjectNode = objectMapper.createObjectNode();
            modelObjectNode.put(ModelDataJsonConstants.MODEL_NAME, "lutiannan");
            modelObjectNode.put(ModelDataJsonConstants.MODEL_REVISION, 1);
            String description = "lutiannan---";
            modelObjectNode.put(ModelDataJsonConstants.MODEL_DESCRIPTION, description);
            modelData.setMetaInfo(modelObjectNode.toString());
            modelData.setName("lutiannan");
            modelData.setKey("12313123");

            //保存模型
            repositoryService.saveModel(modelData);
            repositoryService.addModelEditorSource(modelData.getId(), editorNode.toString().getBytes("utf-8"));
            
            System.out.println("================================");
            System.out.println("ID: ");
            System.out.println("================================");
            
            
            
            response.sendRedirect(request.getContextPath() + "/modeler.html?modelId=" + modelData.getId());
        } catch (Exception e) {
            System.out.println("创建模型失败：");
        }
    }
    
    
    @RequestMapping("test")
    public void test(){
    	// 1、ProcessEngine
    	ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();
    	
    	// 2、Service
    	RuntimeService runtimeService = processEngine.getRuntimeService();
    	RepositoryService repositoryService = processEngine.getRepositoryService();
    	TaskService taskService = processEngine.getTaskService();
    	ManagementService managementService = processEngine.getManagementService();
    	IdentityService identityService = processEngine.getIdentityService();
    	HistoryService historyService = processEngine.getHistoryService();
    	FormService formService = processEngine.getFormService();
    }

    public static Logger logger = Logger.getLogger(Test.class);  
    @RequestMapping("createEngine")
    public void createEngine(){
    	
    	
    	ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();
    	RepositoryService repositoryService = processEngine.getRepositoryService();
    	repositoryService.createDeployment().addClasspathResource("bpmn/MyProcess.bpmn").deploy();
    	
    	Map<String, Object> variables = new HashMap<String, Object>();
    	variables.put("employeeName", "fozzie");
    	variables.put("numberOfDays", new Integer(4));
    	variables.put("vacationMotivation", "I'm really tired!");
    	
    	RuntimeService runtimeService =  processEngine.getRuntimeService();
    	ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("TestProcess", variables);
    	//logger.info("Number of process instances: " + runtimeService.createProcessInstanceQuery().count());
    	
    	TaskService taskService = processEngine.getTaskService();
    	List<Task> tasks = taskService.createTaskQuery().taskAssignee("fozzie").list();
    	
    	for (Task task : tasks) {
    		logger.info("Task available: " + task.getName());
    	}
    	
//    	Task task = tasks.get(0);
//    	Map<String, Object> taskVariables = new HashMap<String, Object>();
//    	taskVariables.put("vacationApproved", "false");
//    	taskVariables.put("managerMotivation", "We have a tight deadline!");
//    	taskService.complete(task.getId(), taskVariables);
    	
    	
//    	logger.error("===================================================");
//    	logger.error("===================================================");
//    	logger.error("===================================================");
//    	logger.error("===================================================");
//    	logger.error("===================================================");
    	repositoryService.suspendProcessDefinitionByKey("TestProcess");
    	try {
    		runtimeService.startProcessInstanceByKey("TestProcess");
    	} catch (ActivitiException e) {
    		e.printStackTrace();
    	}
    	
    	
    }

    @RequestMapping("financial")
    public void financial(){
    	ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();
    	RepositoryService repositoryService = processEngine.getRepositoryService();
    	Deployment deployment = repositoryService.createDeployment()
        		.addClasspathResource("bpmn/FinancialReportProcess.bpmn20.xml")
        		.deploy();
    	
    	RuntimeService runtimeService =  processEngine.getRuntimeService();
    	ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("financialReport");
    	
    	TaskService taskService = processEngine.getTaskService();
    	List<Task> tasks = taskService.createTaskQuery().taskCandidateUser("kermit").list();
//    	List<Task> tasks2 = taskService.createTaskQuery().taskCandidateGroup("accountancy").list();
    	
    	
    	for (Task task : tasks) {
    		logger.error("Task available: " + task.getName());
    	}
    	
    	
    	
    }
    
    @RequestMapping("claim")
    public void claim(){
//    	taskService.claim(task.getId(), "fozzie");
//        List<Task> tasks = taskService.createTaskQuery().taskAssignee("fozzie").list();
    	
    	//taskService.complete(task.getId());
    }
    
    @RequestMapping("demo")
    public void demo(){
    	// Create Activiti process engine
    	ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();
    	// Get Activiti services
    	RepositoryService repositoryService = processEngine.getRepositoryService();
    	RuntimeService runtimeService = processEngine.getRuntimeService();
    	// Deploy the process definition
    	repositoryService.createDeployment().addClasspathResource("bpmn/FinancialReportProcess.bpmn20.xml").deploy();
    	// Start a process instance
    	String procId = runtimeService.startProcessInstanceByKey("financialReport").getId();
    	// Get the first task
    	TaskService taskService = processEngine.getTaskService();
    	List<Task> tasks = taskService.createTaskQuery().taskCandidateGroup("accountancy").list();
    	for (Task task : tasks) {
	    	System.out.println("Following task is available for accountancy group: " + task.getName());
	    	// claim it
	    	taskService.claim(task.getId(), "fozzie");
    	}
    	// Verify Fozzie can now retrieve the task
    	tasks = taskService.createTaskQuery().taskAssignee("fozzie").list();
    	for (Task task : tasks) {
	    	System.out.println("Task for fozzie: " + task.getName());
	    	// Complete the task
	    	taskService.complete(task.getId());
    	}
    	System.out.println("Number of tasks for fozzie: " + taskService.createTaskQuery().taskAssignee("fozzie").count());
    	// Retrieve and claim the second task
    	tasks = taskService.createTaskQuery().taskCandidateGroup("management").list();
    	for (Task task : tasks) {
	    	System.out.println("Following task is available for accountancy group: " + task.getName());
	    	taskService.claim(task.getId(), "kermit");
    	}
    	// Completing the second task ends the process
    	for (Task task : tasks) {
    		taskService.complete(task.getId());
    	}
    	// verify that the process is actually finished
    	HistoryService historyService = processEngine.getHistoryService();
    	HistoricProcessInstance historicProcessInstance =
    	historyService.createHistoricProcessInstanceQuery().processInstanceId(procId).singleResult();
    	System.out.println("Process instance end time: " + historicProcessInstance.getEndTime());
    }
    
    /**
	 * 查询 客户端分页
	 * @return
	 */
	 @RequestMapping(value="selectAll")
	 @ResponseBody
	 public String selectAll(){
		 System.out.println(111);
		 ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();
		 RepositoryService repositoryService = processEngine.getRepositoryService();
	    	
	     List<Model> resultList =  repositoryService.createModelQuery().orderByCreateTime().desc().list();
	     JSONObject resultJson = new JSONObject();
	     resultJson.put("data", resultList);
	     return resultJson.toString();
	 }
	 
	 /** 
	  * 新增
	  * @return 
	  */  
	 @RequestMapping(value = "add")  
	 public void getEditor(
	         @RequestParam("description") String description,
	         @RequestParam("name") String name,
	         @RequestParam("key") String key,
	         HttpServletRequest request, HttpServletResponse response){  
	     try {
	    	 description = "11";
	    	 name = "";
	    	 key = "";
	    	 ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();
			 RepositoryService repositoryService = processEngine.getRepositoryService();
			 
	         ObjectMapper objectMapper = new ObjectMapper();
	         ObjectNode editorNode = objectMapper.createObjectNode();
	         editorNode.put("id", "canvas");
	         editorNode.put("resourceId", "canvas");
	         ObjectNode stencilSetNode = objectMapper.createObjectNode();
	         stencilSetNode.put("namespace", "http://b3mn.org/stencilset/bpmn2.0#");
	         editorNode.put("stencilset", stencilSetNode);
	         Model modelData = repositoryService.newModel();
	         ObjectNode modelObjectNode = objectMapper.createObjectNode();
	         modelObjectNode.put(ModelDataJsonConstants.MODEL_NAME, name);
	         modelObjectNode.put(ModelDataJsonConstants.MODEL_REVISION, 1);
	         description = StringUtils.defaultString(description);
	         modelObjectNode.put(ModelDataJsonConstants.MODEL_DESCRIPTION, description);

	         modelData.setMetaInfo(modelObjectNode.toString());
	         modelData.setName(name);
	         modelData.setKey(StringUtils.defaultString(key));

	         repositoryService.saveModel(modelData);
	         repositoryService.addModelEditorSource(modelData.getId(), editorNode.toString().getBytes("utf-8"));
	         System.out.println("跳转页面");
	         response.sendRedirect(request.getContextPath() + "/service/editor?id=" + modelData.getId());
	     } catch (Exception e) {
	        System.out.println("创建模型失败");
	     }
	 }  
	 
	 /**
	  * 查询 客户端分页
	  * @return
	  */
	 @RequestMapping(value="processList")
	 @ResponseBody
	 public List<Map<String, Object>> processList(){
		 List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		 Map<String,Object> map = new HashMap<String, Object>();
		 map.put("a", 1);
		 map.put("b", 2);
		 list.add(map);
		 Map<String,Object> map2 = new HashMap<String, Object>();
		 map2.put("a", 3);
		 map2.put("b", 4);
		 list.add(map2);
		 
		 return list;
	 }
	 
}  
